# OUTBASE GENIUS UI

## 方針
「カッコいい」と「便利」を同時に狙った再設計。
新しい技術: CSS Grid / sticky glass header / localStorage PWA / Canvas route map / touch swipe calendar
古い技術: 黒・真鍮・木・紙の道具感、コントロールパネル的な構成

## 主な変更
- ホームを宣伝コピーではなく、Control Boardへ変更。
- 画面上部にステージ切替（準備前 / 準備中 / 現地 / 帰宅後）。
- カレンダーは単体・連日・キャンプ・繰り返しを視覚的に分離。
- 準備は料理 / 買い物 / ギア / 天気。
- ギアは一覧 / ボックス / 積込 / 乾燥修理 / 取込。
- 現地は散歩GPS / 簡易地図 / スポット / 犬友達 / 非公開体調メモ。
- うんち/おしっこは表に出さず、非公開体調メモ内のみ。


## scroll fix
- `.shell { overflow:hidden }` がモバイルChromeで sticky header を壊していたため解除。
- sticky header 側に角丸と z-index を持たせ、スクロール時もヘッダーが消えないように修正。
- body背景の途中から黒帯が見える問題を避けるため、外側背景を安定した黒に変更。
- モバイルではヘッダー角丸を消して、スクロール時に自然に固定されるよう調整。
