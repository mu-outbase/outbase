#!/usr/bin/env bash
set -euo pipefail

LIB="outbase_library10a"
APP="$LIB/src/app.js"
HOTFIX="$LIB/src/hotfix.js"
INDEX="$LIB/index.html"

for file in "$APP" "$HOTFIX" "$INDEX" "$LIB/style.css" "$LIB/manifest.json" "$LIB/service-worker.js"; do
  if [[ ! -f "$file" ]]; then
    echo "Required file missing: $file" >&2
    exit 1
  fi
done

# Prevent duplicate integration.
if grep -q "Library10A-HOTFIX3-INTEGRATED" "$APP"; then
  echo "HOTFIX3 is already integrated."
else
  tmp_app="$(mktemp)"
  cat "$APP" > "$tmp_app"
  printf '\n\n/* Library10A-HOTFIX3-INTEGRATED */\n' >> "$tmp_app"
  cat "$HOTFIX" >> "$tmp_app"
  mv "$tmp_app" "$APP"
  echo "Integrated hotfix.js into app.js."
fi

# Remove the separate hotfix script and bump the app cache key.
python3 - <<'PY'
from pathlib import Path
import re

path = Path("outbase_library10a/index.html")
text = path.read_text(encoding="utf-8")

text = re.sub(
    r'\s*<script\s+src="src/hotfix\.js\?[^"]*"\s+defer></script>\s*',
    '\n',
    text,
)
text = re.sub(
    r'src/app\.js\?v=[^"]+',
    'src/app.js?v=outbase-library10a-integrated1',
    text,
)
text = re.sub(
    r'style\.css\?v=[^"]+',
    'style.css?v=outbase-library10a-integrated1',
    text,
)
text = re.sub(
    r'manifest\.json\?v=[^"]+',
    'manifest.json?v=outbase-library10a-integrated1',
    text,
)

path.write_text(text, encoding="utf-8")
PY

# Promote the integrated Library10A implementation to repository root.
mkdir -p src
cp "$LIB/index.html" index.html
cp "$LIB/style.css" style.css
cp "$LIB/manifest.json" manifest.json
cp "$LIB/service-worker.js" service-worker.js
cp "$APP" src/app.js

# Root-specific cache key.
python3 - <<'PY'
from pathlib import Path
import re, json

index = Path("index.html")
text = index.read_text(encoding="utf-8")
text = text.replace("outbase-library10a-integrated1", "outbase-root-integrated1")
index.write_text(text, encoding="utf-8")

manifest_path = Path("manifest.json")
manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
manifest["start_url"] = "./?v=outbase-root-integrated1"
manifest_path.write_text(
    json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
    encoding="utf-8",
)

sw_path = Path("service-worker.js")
sw = sw_path.read_text(encoding="utf-8")
sw = re.sub(
    r"const CACHE_NAME\s*=\s*['\"][^'\"]+['\"]",
    "const CACHE_NAME = 'outbase-root-integrated1'",
    sw,
)
sw_path.write_text(sw, encoding="utf-8")
PY

# Basic integrity checks.
grep -q "Library10A-HOTFIX3-INTEGRATED" "$APP"
grep -q "Library10A-HOTFIX3-INTEGRATED" "src/app.js"

if grep -q 'src/hotfix.js' "$INDEX"; then
  echo "Separate hotfix reference still remains in Library10A index." >&2
  exit 1
fi
if grep -q 'src/hotfix.js' index.html; then
  echo "Separate hotfix reference still remains in root index." >&2
  exit 1
fi

node --check "$APP"
node --check "src/app.js"

echo "OUTBASE Library10A integration and root promotion completed."
