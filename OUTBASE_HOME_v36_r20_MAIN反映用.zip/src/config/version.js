(() => {
  'use strict';
  const VERSION=Object.freeze({
    app:'v166.3-visual-hierarchy-lock',
    legacy:'outbase-field03-compact-2',
    data:'outbase-v160-phase1',
    domain:'outbase-v1663-home-v36-r20',
    shell:'outbase-v1663-home-v36-r20',
    design:'outbase-v1663-visual',
    cache:'outbase-field03-v1663-visual-home-v36-r20'
  });
  globalThis.OUTBASE_VERSION=VERSION;
})();
